<?php
    include './includes/common.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include './includes/links.php'; ?>
    <title>About | Mobile Store</title>
</head>
<body>
    
    <?php
            include './includes/header.php';
        ?>
   
        <div class="content">
            <div class="container">
              
            <div class="row">
                <div class="col-md-4">
                  <h3 class="about-h3 text-uppercase">Who We Are</h3>                  
                  <div class="box-padding-10">
                  <img src="./img/who-we-are.png" alt="" class="img-responsive img-circle about-img">  
                  <p class="text-muted about-p">We have been established at our current site for over 9 years.Between our friendly and knowledgeable staff, with over 20 years experience in the mobile industry, we are able to deal with most mobile phone and tablet needs.</p>                
                  </div>
                </div>

                <div class="col-md-4">
                  <h3 class="about-h3">OUR HISTORY</h3>
                  <div class="box-padding-10">
                  <p class="p-bold p-blue">1999 -</p>
                  <p class="text-muted"> The MobileStore was launched on 22 March 1999 in Bangladesh, incorporated under The Companies Act, 1956. It has its registered office at 11 RN Road Jessore </p>

                  <p class="p-bold p-blue">2002 -</p>
                  <p class="text-muted"> The pioneering spirit of people moving west and both opening and shopping at local general stores evolved as the United States moved into the 20th century. </p>

                  <p class="p-bold p-blue">2006 -</p>
                  <p class="text-muted"> In the late 19th and early 20th centuries, America’s business and economic sectors changed dramatically. </p>

                </div>
                </div>

                <div class="col-md-4">
                  <h3 class="about-h3">OPPURTUNITIES</h3>
                  <div class="box-padding-10">
                    <p class="p-bold">Availabe Roles</p>
                    <div class="box-padding-left">
                      <p class="text-muted">
                        1. Jr./Sr. Web Developer<br>
                        2. Graphic Designer<br>
                        3. Web Designer<br>
                        4. Front End Developer<br>
                        5. Back End Developer<br>
                        6. Database Admin<br>
                        7 .System Admin<br>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    
    <?php
        include './includes/footer.php';
    ?>
    
</body>
</html>